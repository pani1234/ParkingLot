/**
 * Created by pania on 2/11/18.
 */
import java.util.*;
public class utility {
    static void slot_numbers_for_cars_with_colour (String color)
    {
        String str_display = "";
        for(Map.Entry<Integer, Car> entry:parking_lot.parking_table.entrySet()){
            if(entry.getValue().color.equals(color))
            {
                str_display += entry.getKey() + ", ";
            }
        }
        str_display = str_display.replaceAll(", $", "");
        System.out.println(str_display);
    }

    static void slot_number_for_registration_number (String registration)
    {
        String str_display = "";
        for(Map.Entry<Integer, Car> entry:parking_lot.parking_table.entrySet()){
            if(entry.getValue().registration_number.equals(registration))
            {
                System.out.println(entry.getKey());
                break;
            }
        }
    }

    static void registration_numbers_for_cars_with_colour (String color)
    {
        String str_display = "";
        for(Map.Entry<Integer, Car> entry:parking_lot.parking_table.entrySet()){
            if(entry.getValue().color.equals(color))
            {
                str_display += entry.getValue().registration_number + ", ";
            }
        }
        str_display = str_display.replaceAll(", $", "");
        System.out.println(str_display);
    }

    static void status ()
    {
        System.out.println("Slot No.    Registration No      Colour");
        String str_display = "";
        for(Map.Entry<Integer, Car> entry:parking_lot.parking_table.entrySet()){
            str_display = "";
            str_display = entry.getKey() + "    " + entry.getValue().registration_number + "    " + entry.getValue().color;
            System.out.printf("%-11d %-20s %-20s",  entry.getKey(), entry.getValue().registration_number, entry.getValue().color);
            System.out.print('\n');
        }
    }
}
