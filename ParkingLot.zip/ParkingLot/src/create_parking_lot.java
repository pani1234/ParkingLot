import java.util.Hashtable;
import java.util.PriorityQueue;
import java.io.*;
import java.util.*;
//import com.google.common.collect.BiMap;
//import com.google.common.collect.HashBiMap;
/**
 * Created by pania on 2/11/18.
 */
public class create_parking_lot {


    static void create(int num)
    {
        try {

            //create a priority queue of the available slots so that everytime we remove an item we get the closest slot
            //assuming the slot with the lower slot_number is closer to the entry of the parking lot
            parking_lot.slot_PQ = new PriorityQueue<>();
            for (int i = 1; i <= num; i++) {
                parking_lot.slot_PQ.add(i);
            }
            //treemap of slot_number->Car
            parking_lot.parking_table = new TreeMap();

            System.out.println("Created a parking lot with " + num + " slots");
            return;
        }

        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}
