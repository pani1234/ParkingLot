/**
 * Created by pania on 2/11/18.
 */
class Car {
    String registration_number;
    String color;
    Car(String car_number, String carColor)
    {
        registration_number = car_number;
        color = carColor;
    }
}

