/**
 * Created by pania on 2/11/18.
 */
import java.util.Hashtable;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.TreeMap;

public class parking_lot {
    static TreeMap<Integer, Car> parking_table;
    static PriorityQueue<Integer> slot_PQ;
    public static void main(String[] args) {
        try {

            Scanner scanner;

            slot_management pc = new slot_management();
            utility util =  new utility();
            String str = "";
            boolean filemode = false;

            if(args.length == 0) {
                scanner = new Scanner(System.in);
                System.out.print("$ ");
                str = scanner.nextLine();
            }
            else
            {
                filemode = true;
                File file = new File(args[0]);
                if(file.exists())
                {
                    scanner = new Scanner(file);
                    if(scanner.hasNextLine()) {
                        str = scanner.nextLine();
                    }
                }
                else
                {
                    System.out.println("File does not exists");
                    return;
                }

            }

            while (true) {
                if (filemode)
                {
                    if(!scanner.hasNextLine()) {
                        break;
                    }
                }
                else
                {
                    if(str.equals("exit"))
                    {
                        break;
                    }
                }

                String[] input = str.split(" ");
                if(input[0].equals("create_parking_lot")) {
                    create_parking_lot.create(Integer.parseInt(input[1]));
                }
                else if (input[0].equals("park")) {
                    slot_management.park(input[1], input[2]);
                } else if (input[0].equals("leave")) {
                    slot_management.leave(Integer.parseInt(input[1]));
                } else if (input[0].equals("slot_numbers_for_cars_with_colour")) {
                    util.slot_numbers_for_cars_with_colour(input[1]);
                }
                else if (input[0].equals("slot_number_for_registration_number")) {
                    util.slot_number_for_registration_number(input[1]);
                }
                else if (input[0].equals("registration_numbers_for_cars_with_colour")) {
                    util.registration_numbers_for_cars_with_colour(input[1]);
                }
                else if (input[0].equals("status")) {
                    util.status();
                }
                if(!filemode) {
                    System.out.print("$ ");
                }
                if(scanner.hasNextLine()) {
                    str = scanner.nextLine();
                }
            }
            scanner.close();
            return;
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}

