/**
 * Created by pania on 2/11/18.
 */
public class slot_management {
    static void park(String registration, String color)
    {
        if(parking_lot.slot_PQ.size() > 0) {
            int slot_number = parking_lot.slot_PQ.remove();
            Car car = new Car(registration, color);
            parking_lot.parking_table.put(slot_number, car);
            System.out.println("Allocated slot number: " + slot_number);
            return;
        }
        else {
            System.out.println("Sorry, parking lot is full");
            return;
        }
    }

    static void leave(int slot_number)
    {
        parking_lot.parking_table.remove(slot_number);
        parking_lot.slot_PQ.add(slot_number);
        System.out.println("Slot number " + slot_number + " is free");
    }
}
